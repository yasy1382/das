<?php if(!isset($_SESSION)){
	session_start();
	}  
?>

<?php include('header.php'); ?>




	<!-- this is for donor registraton -->
	<div class="recipient_reg" style="background-color:#272327;">
		<h3  style="text-align:center;background-color:#272327;color: #fff;">اضافه کردن پزشک</h3>

		<div dir="rtl" class="formstyle" style="float: right;padding:25px;border: 1px solid lightgrey;margin-right:320px; margin-bottom:30px;background-color: #101011;color:#d4530d;;">
		<form enctype="multipart/form-data" action=""  method="post" class="text-center" style="font-family:IRANSans;margin-left: 110px">
			 <div class="col-md-12" >
				  	
			 		
					<label>
					    <input style="font-family: IRANSans;" type="text" name="name" value="" placeholder="نام و نام خانوادگی" autocomplete="on">
					</label><br><br>
                 <label>
                     <select style="font-family: IRANSans;" name="address" id="options" >
                         <option>-نام بیمارستان-</option>
                         <?php
                         include('../config.php');


                         $sql = " SELECT DISTINCT address  FROM category";
                         $result = mysqli_query($conn,$sql);
                         $count = mysqli_num_rows($result);
                         $hos=array();
                         $i=0;
                         if($count>=1) {
                             while ($row = mysqli_fetch_array($result)) {
                                 echo "<option>" . $row['address'] . "</option>";
                                 $hos[$i++]=$row['address'];


                             }
                         }


                         ?>
                     </select>
                 </label><br><br>
					<label>
						 <input style="font-family: IRANSans;" type="text" name="contact" value="" placeholder="شماره تماس" >
					</label><br><br>

					<label>
						 <input style="font-family: IRANSans;" type="email" name="email"  value="" placeholder="ایمیل" >
					</label><br><br>
					
					<label>
						 <select style="font-family: IRANSans;" name="expertise" id="choices" >
                             <option value="" disabled selected>-تخصص-</option>

                         </select>
					</label><br><br>
					<label>
					     <input style="font-family: IRANSans;" type="text" name="userid" value="" placeholder="شماره کاربری" >
					</label><br><br>
					<label>
					   <input style="font-family: IRANSans;" type="text" name="fee" value="" placeholder="هزینه" >
					</label><br><br>
					<label>
					   <input style="font-family: IRANSans;" type="password" name="password" value="" placeholder="کلمه عبور" >
					</label><br><br>
					<label>
						 <input style="font-family: IRANSans;" type="file" name="pic" value="" id="pic" required>
					</label><br><br>
					
					<button  name="submit" type="submit" style="font-family:IRANSans;margin-right:230px;margin-top: 20px;width:95px;border-radius: 3px;height: 30px">اضافه کردن</button> <br>
				
			</div>	<!-- col-md-12 -->


				</form>
			</div>




	</div>
	
	

					<!-- inserting data -->
					<?php  
						 if(isset($_POST['submit'])){
							$target_dir = "../img/";
							$target_file = $target_dir . basename($_FILES["pic"]["name"]);
							$uploadOk = 1;
							$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
							// Check if image file is a actual image or fake image

						    $check = getimagesize($_FILES["pic"]["tmp_name"]);
						    if($check !== false) {
						        // echo "File is an image - " . $check["mime"] . ".";
						        $uploadOk = 1;
						    } else {
						        echo "فایل شما فرمت تصویر نیست";
						        $uploadOk = 0;
						    }

							// Check if file already exists
							if (file_exists($target_file)) {
							    echo "<script>alert('فایل مورد نظر از قبل موجود است');</script>";
							    $uploadOk = 0;
							}
							//aloow certain file formats
							if($imageFileType != "jpg" && $imageFileType !="png" && $imageFileType !="jpeg" && $imageFileType !="gif"){
								echo "فرمت های jpg, jpeg, Png & gif قابل پذییرش هستند";
								$uploadok=0;
							}	
						else{
							if(move_uploaded_file($_FILES["pic"]["tmp_name"], $target_file)) {
									include('../config.php');
									$sql1 = "SELECT * FROM doctor WHERE userid='".$_POST["userid"]."' OR email= '" . $_POST["email"] . "' ";
	              					$result = $conn->query($sql1);
	              					if($result->num_rows > 0){
	              						 echo "<script>alert('شماره کاربری یا ایمیل قبلاً ثبت شده است');</script>";
	              					}
	              					else{
									$sql = "INSERT INTO doctor (name,address,contact,email,expertise,userid,fee,password,pic)
										VALUES ('" . $_POST["name"] . "','" . $_POST["address"] . "','" . $_POST["contact"] . "','" . $_POST["email"] . "', '" . $_POST["expertise"] . "','" . $_POST["userid"] . "','" . $_POST["fee"] . "','" . $_POST["password"] . "','" . basename($_FILES["pic"]["name"]) ."' )";

										if ($conn->query($sql) === TRUE) {
										    echo "<script>alert('اطلاعات پزشک جدید با موفقیت ثبت شد');</script>";
										} else {
										    echo "<script>alert('خطا در سیستم')<script>";
										}
									}

									$conn->close();
							} else {
								echo "<script>alert('خطا در سیستم');</script>";
							}
							
							
						}
				}
				?>
					<!-- inserting data -->

	



	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

<script>
    var lookup = {
        <?php
        $i=0;
        for($i=0;$i<count($hos);$i++)
        {
            echo '\'';
            echo $hos[$i];
            echo '\'';
            $sql = " SELECT DISTINCT cat FROM category WHERE address='".$hos[$i]."'";
            $result = mysqli_query($conn,$sql);
            $count = mysqli_num_rows($result);
            if($count>=1){
                echo ": [";
                while($row=mysqli_fetch_array($result)){
//                    echo ": ['1', '2', '3'],";
                    echo '\'';
                    echo $row['cat'];
                    echo '\'';
                    echo ',';

                }
                echo '],';
            }

        }


        ?>

    };

    // When an option is changed, search the above for matching choices
    $('#options').on('change', function() {
        // Set selected option as variable
        var selectValue = $(this).val();

        // Empty the target field
        $('#choices').empty();

        // For each chocie in the selected option
        for (i = 0; i < lookup[selectValue].length; i++) {
            // Output choice in the target field
            $('#choices').append("<option value='" + lookup[selectValue][i] + "'>" + lookup[selectValue][i] + "</option>");
        }
    });

</script>






</body>
</html>