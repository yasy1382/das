<?php if(!isset($_SESSION)){
    session_start();
}
?>

<?php include('header.php'); ?>




<!-- this is for donor registraton -->
<div class="recipient_reg" style="background-color:#272327;">
    <h3  style="text-align:center;background-color:#272327;color: #fff;">اضافه کردن تخصص</h3>

    <div dir="rtl" class="formstyle" style="float: right;padding:25px;border: 1px solid lightgrey;margin-right:320px; margin-bottom:30px;background-color: #101011;color:#d4530d;;">
        <form enctype="multipart/form-data" action=""  method="post" class="text-center" style="font-family:IRANSans;margin-left: 110px">
            <div class="col-md-12" >


                <label>
                    <input style="font-family: IRANSans;" type="text" name="address" value="" placeholder=" نام بیمارستان" autocomplete="on">
                </label><br><br>
                <label>
                    <input style="font-family: IRANSans;" type="text" name="expertise" value="" placeholder="تخصص جدید" autocomplete="on">
                </label><br><br>

                <button  name="submit" type="submit" style="font-family:IRANSans;margin-right:230px;margin-top: 20px;width:95px;border-radius: 3px;height: 30px">اضافه کردن</button> <br>

            </div>	<!-- col-md-12 -->


        </form>
    </div>




</div>



<!-- inserting data -->
<?php
if(isset($_POST['submit'])){
    include('../config.php');

            $sql1 =" SELECT * FROM category WHERE address = '" . $_POST["address"]."' AND cat = '" . $_POST["expertise"]."' ";

    $result = $conn->query($sql1);
            if($result->num_rows > 0){
                echo "<script>alert('این تخصص قبلاً در بیمارستان مورد نظر ثبت شده است');</script>";
            }
            else{
                $sql = "INSERT INTO category (cat,address) VALUES ('" . $_POST["expertise"] . "', '" . $_POST["address"] . "')";

                if ($conn->query($sql) === TRUE) {
                    echo "<script>alert('تخصص جدید با موفقیت ثبت شد');</script>";
                } else {
                    echo "<script>alert('خطا در سیستم')<script>";
                }
            }

            $conn->close();




}
?>
<!-- inserting data -->






</div><!--  containerFluid Ends -->




<script src="js/bootstrap.min.js"></script>






</body>
</html>