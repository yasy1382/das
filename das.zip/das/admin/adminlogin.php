<?php session_start();  ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>سیستم نوبت دهی پزشک</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="../RtlStyle.css">

    <style>
		.error {color: #FF0000;}
	</style>
</head>
<body>



	<div class="container">
		<div class="header_top" dir="rtl">
            <span style="font-family:IRANSans;text-align:right;font-size:40px;color:#2c2f84;font-weight:bolder;">سیستم نوبت دهی پزشک</span>
		</div>

	<!-- 	this is for menu -->
	<div class="navbar navbar-default nav">
		<nav class="menu">
			<ul>
				<li><a href="../index.php">صفحه اصلی</a></li>
				
				<li><a href="logout.php">خروج</a></li>
			</ul>
		</nav>
	</div>
	






	<!-- this is for donor registraton -->
	<div class="login">
		<!-- <h1 class="text-center" style="background-color:;color: #fff;">Admin Panel</h1> -->
			<div dir="rtl" class="formstyle" style="font-family:IRANSans;padding: 10px;border: 1px solid lightgrey;margin-right: 376px;margin-left: 406px; margin-bottom: 25px;background-color:black;">
				<form action="" method="post" class="text-center" >
					<label>
						<input type="text" name="username"  placeholder="نام کاربری" required style="margin-right: 75px;font-family: IRANSans;">
					</label><br><br>
					<label>
						<input type="password" name="password"  placeholder="کلمه عبور" required style="margin-right: 75px;font-family: IRANSans;">
					</label><br><br>
					<button name="submit" type="submit" style="font-family:IRANSans;margin-top:3px;padding:3px 25px; border-radius:4px;float:left;margin-left:218px;">ورود</button> <br>

					

					<!-- login validation -->
			<?php 
							$_SESSION['adminstatus']="";
							include('../config.php');
							if(isset($_POST["submit"])){

							$sql= "SELECT * FROM users WHERE username= '" . $_POST["username"]."' AND password= '" . $_POST["password"]."'";

							$result = $conn->query($sql);

									if ($result->num_rows > 0) {
											$_SESSION["username"]= $_POST["username"];
											
											$_SESSION['adminstatus']= "yes";
										    echo "<script>location.replace('dashboard.php');</script>";
												// echo "u are supposed to redirect to ur profile";
										} else {
										    echo "<span style='color:red;'>نام کاربری یا رمز عبور درست نمی باشد</span>";
										}
						$conn->close();		
					}
					
 			?>
		<!-- login validation End-->


				</form> <br>&nbsp;&nbsp;&nbsp;
				
				<br>

				
		
				
			
		
	</div>
	
	
</div>
	
<?php include('footer.php'); ?>

	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>


 
			



	
</body>
</html>

