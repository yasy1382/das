<?php if(!isset($_SESSION)){
	session_start();
	}  
?>

<?php include('header.php'); ?>
<!-- this is for donor registraton -->
	<div style="font-family:IRANSans;background-color:#fff;">
		<h3  style="text-align:center;background-color:#272327;color: #fff;padding: 5px;">پنل مدیریت</h3>
		<div  style="text-align:center;font-size: 45px;font-weight: bold;color: blue;font-family: IRANSans;">به پنل مدیریت خوش آمدید</div>
        <br>
        <br>
        <br>
	</div>
	
	
<?php include('footer.php'); ?>

</div><!--  containerFluid Ends -->

<script src="js/bootstrap.min.js"></script>

</body>
</html>
