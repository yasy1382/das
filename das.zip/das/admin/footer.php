   <!-- footer section --> 
			<footer>
			<div class="col-md-12">
				<div class="col-md-4"></div>
				<div class="col-md-4 fsection">
					<p style="text-align: left;" class="text-center">&copy;<?php echo date('Y') ?>-All Rights Reserved By Admin</p>
				</div>
				<div class="col-md-4"></div>
			</div>

			</footer>

		<!-- footer section Ends--> 
