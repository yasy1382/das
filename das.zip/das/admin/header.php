<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>سیستم نوبت دهی پزشک </title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="../RtlStyle.css">


    <style>
		.error {color: #FF0000;}
	</style>
</head>
<body>


<?php
		if($_SESSION['adminstatus'] == ""){
			header("location:adminlogin.php");
		}
		
		   

	 ?>


<div class="container-fluid" dir="rtl">
    <div class="header_top" style="text-align: right;padding-right: 20px;padding-top: 20px;">
			<span style="font-size:50px;color:#2c2f84;font-weight:bolder;margin-left:15px;">سیستم نوبت دهی پزشک</span>
		</div>

	<!-- 	this is for menu -->
	<div class="navbar navbar-default nav" style="height: 42px;">
		<nav class="menu">
			<ul>
				
				
				
				<li><a href="addDoctor2.php">اضافه کردن پزشک</a></li>
                <li><a href="addcatalogy.php">اضافه کردن تخصص</a></li>
				<li><a href="viewDoctor.php">مشاهده پزشکان</a></li>
				<li><a href="viewCustomer.php">مشاهده بیماران</a></li>
				<li><a href="viewAppoinment.php">مشاهده نوبت ها</a></li>
				<li><a href="viewFeedback.php">مشاهده پیام ها</a></li>
				<li><a href="logout.php">خروج</a></li>
			</ul>
		</nav>
	</div>
	
