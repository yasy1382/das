<?php include('header.php'); ?>




	<!-- this is for donor registraton -->
	<div class="contactus"  style="background-color:#fff;">
		<h3 class="text-center" style="height:30px;background-color:#272327;color: #fff;">تماس با ما</h3>

		
		
		<div class="main_content" dir="rtl">
			<div class="col-md-6" style="border-right: 2px solid black;">
				<article>
					<h2>راه های ارتباطی ضروری <h2><h4>برای ارتباط با بخش های ویژه می توانید از طریق راههای زیر تماس حاصل فرمایید</h4>
							<h5>ارتباط با بخش مدیریت و ریاست از طریق وب سایت های زیر همه روزه انجام می شود</h5>
						<p> https://portfolio.developerazad.com <br>
							https://developerazad.wordpress.com <br>
							https://linkedin.com/in/developerazad <br>
							https://facebook/developerazad <br>
							تلفن : +98 02164761919</p><br>
				</article>
			</div>
			<div class="col-md-6">
				<h2 >پیام شما</h2>
				<form action="" method="post" class="text-center">
						<label>
                             <input type="text" name="firstname" value="" placeholder="نام" required>
						</label><br><br>

						<label>
                            <input type="text" name="lastname" value="" placeholder="نام خانوادگی" required>
						</label><br><br>	

						<label>
								 <input type="email" name="email"  value="" placeholder="ایمیل" required>
						</label><br><br>
						<label>
                             <textarea name="comment" id="" cols="30" rows="4" placeholder="متن پیام" required></textarea>
						</label><br><br>
								
						<input type="submit" value="ارسال نظر" name="submit" style="margin-right:0;margin-top: 75px;border-radius: 2px;"/>
						<!-- <button name="submit" type="submit" class="btn btn-info"><i class="icon-signin icon-large"></i>&nbsp;Sign Up</button>
 -->
					</form><br><br><br>
			</div>

          
 		</div>

	</div>
	
	

	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>


 
<!-- contact information inserting -->
					<?php

						include('config.php');
						if(isset($_POST['submit'])){
							

							$sql = "INSERT INTO contact (firstname, lastname,email,comment)
							VALUES ('" . $_POST["firstname"] ."','" . $_POST["lastname"] . "','" . $_POST["email"] . "','" . $_POST["comment"] . "' )";

							if ($conn->query($sql) === TRUE) {
							    echo "<script>location.replace('success.php');</script>";
							} else {
							    echo "<script>alert('خطا در سیستم دوباره سعی کنید')<script>" . $sql . "<br>" . $conn->error;
							}

							$conn->close();
						}
					?> 



	
</body>
</html>

