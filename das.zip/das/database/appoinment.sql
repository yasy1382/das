-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2022 at 09:06 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `appoinment`
--

-- --------------------------------------------------------

--
-- Table structure for table `Representative doctor`
--

CREATE TABLE `Representative doctor` (
  `bg_id` int(11) NOT NULL,
  `bg_name` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Representative doctor`
--

INSERT INTO `Representative doctor` (`bg_id`, `bg_name`) VALUES
(1, '1'),
(2, '2'),
(3, '3'),
(4, '4'),
(5, '5'),
(6, '6'),

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(22) NOT NULL,
  `dname` varchar(40) NOT NULL,
  `userid` int(22) NOT NULL,
  `dcontact` varchar(22) NOT NULL,
  `expertise` varchar(40) NOT NULL,
  `fee` varchar(22) NOT NULL,
  `pname` varchar(40) NOT NULL,
  `pcontact` varchar(22) NOT NULL,
  `email` varchar(111) NOT NULL,
  `address` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `tyme` varchar(22) NOT NULL,
  `payment` varchar(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `dname`, `userid`, `dcontact`, `expertise`, `fee`, `pname`, `pcontact`, `email`, `address`, `dates`, `tyme`, `payment`) VALUES
(1, 'دکتر صبا احمدی', 11, '091523256', 'شکستگی و سوختگی', '35000', 'یاسمن', '1', 'yasymasoomi@gmail.com', 'کرمان', '2022-07-03', '11.00am', 'bKask');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(22) NOT NULL,
  `cat` varchar(40) NOT NULL,
  `address` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `cat`, `address`) VALUES
(11, 'قلب و عروق', 'بیمارستان شهدا'),
(12, 'مغز و اعصاب', 'بیمارستان شهدا'),
(13, 'زنان و زایمان', 'بیمارستان شهدا'),
(14, 'قرینه و چشم', 'بیمارستان شهدا'),
(15, 'داخلی و اطفال', 'بیمارستان شهدا'),
(16, 'ارولوژیست', 'بیمارستان شهدا'),
(17, 'پوست و مو', 'بیمارستان شهدا'),
(18, 'پزشک عمومی', 'بیمارستان شهدا'),
(19, 'قلب و عروق', 'بیمارستان مدنی'),
(20, 'مغز و اعصاب', 'بیمارستان مدنی'),
(21, 'داخلی و اطفال', 'بیمارستان مدنی'),
(22, 'قرینه و چشم', 'بیمارستان مدنی'),
(23, 'زنان و زایمان', 'بیمارستان مدنی'),
(24, 'ارولوژیست', 'بیمارستان مدنی'),
(25, 'مغز و اعصاب', 'بیمارستان امام'),
(26, 'ارولوژیست', 'بیمارستان امام'),
(27, 'داخلی و اطفال', 'بیمارستان امام'),
(28, 'قلب و عروق', 'بیمارستان امام'),
(29, 'قرینه و چشم', 'بیمارستان امام'),
(30, 'قلب و عروق', 'بیمارستان ارتش'),
(32, 'زنان و زایمان', 'بیمارستان ارتش'),
(33, 'داخلی و اطفال', 'بیمارستان ارتش'),
(34, 'قرینه و چشم', 'بیمارستان ارتش'),
(35, 'ارولوژیست', 'بیمارستان ارتش'),
(36, 'شکستگی و سوختگی', 'بیمارستان باهنر'),
(37, 'داخلی و اطفال', 'بیمارستان باهنر');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `contact_id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `email` varchar(15) NOT NULL,
  `comment` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`contact_id`, `firstname`, `lastname`, `email`, `comment`) VALUES
(1, 'یاسمن', 'معصومی', 'yasymasoomi@gmail.com', 'این یک پیام تستی است.');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `doc_id` int(22) NOT NULL,
  `doctor_id` varchar(22) NOT NULL,
  `name` varchar(40) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` varchar(14) NOT NULL,
  `email` varchar(40) NOT NULL,
  `expertise` varchar(30) NOT NULL,
  `id` int(11) NOT NULL,
  `fee` varchar(111) NOT NULL,
  `userid` varchar(22) NOT NULL,
  `password` varchar(22) NOT NULL,
  `pic` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doc_id`, `doctor_id`, `name`, `address`, `contact`, `email`, `expertise`, `id`, `fee`, `userid`, `password`, `pic`) VALUES
(20, '', 'دکتر سعید نیک نام', 'بیمارستان شهدا', '09143256859', 'Dr.saeedniknam@gmail.com', 'قلب و عروق', 0, '38000', '001', '123', 'doctor3.jpg'),
(23, '', 'دکتر حسن آریا', 'بیمارستان شهدا', '02156893254', 'dr.hasanariya@gmail.com', 'داخلی و اطفال', 0, '39000', '002', '1234', 'doctor1.jpg'),
(24, '', 'دکتر معصومه فرج پور', 'بیمارستان شهدا', '02185856598', 'Dr.m-farajpour@gmail.com', 'زنان و زایمان', 0, '2800', '003', '1234', 'doctor5.jpg'),
(25, '', 'دکتر شیرین بهرامی', 'بیمارستان شهدا', '02156894152', 'Dr.Sh-bahrami@gmail.com', 'مغز و اعصاب', 0, '49000', '004', '1234', 'doctor4.jpg'),
(26, '', 'دکتر امیر جلیلی', 'بیمارستان شهدا', '09125658336', 'Dr.amir-jalilli@GMAIL.COM', 'قرینه و چشم', 0, '42000', '005', '1234', 'doctor2.jpg'),
(27, '', 'دکتر نسیم سینایی', 'بیمارستان شهدا', '0215896523', 'Dr.nasimsinayi@gmail.com', 'ارولوژیست', 0, '45000', '006', '123', 'doctor8.jpg'),
(28, '', 'دکتر سیمین اسلامی', 'بیمارستان شهدا', '03252650004', 'Dr.simineslami@yahoo.com', 'پوست و مو', 0, '38000', '009', '123', 'doctor17.jpg'),
(29, '', 'دکتر سام محمدی', 'بیمارستان شهدا', '0215685956', 'Dr.s-mohammadi@yahoo.com', 'پزشک عمومی', 0, '36000', '010', '123', 'doctor9.jpg'),
(30, '', 'دکتر صبا احمدی', 'بیمارستان باهنر', '091523256', 'Dr.saba-ahmadi@gmail.com', 'شکستگی و سوختگی', 0, '35000', '011', '123', 'doctor19.jpg'),
(31, '', 'دکتر اسماعیل کریمی', 'بیمارستان مدنی', '09125655656', 'Dr.esmael-karimi@gmail.com', 'داخلی و اطفال', 0, '36000', '012', '123', 'doctor12.jpg'),
(33, '', 'دکتر امین اکبری', 'بیمارستان مدنی', '091525625', 'Dr.aminakbari@yahoo.com', 'قرینه و چشم', 0, '39000', '013', '123', 'doctor14.jpg'),
(34, '', 'دکتر سمانه بابایی', 'بیمارستان مدنی', '096523289', 'Dr.samane-babayi@gmail.com', 'زنان و زایمان', 0, '28000', '014', '123', 'doctor21.jpg'),
(35, '', 'دکتر حسن تقوی', 'بیمارستان امام', '0325255654', 'Dr.Hasan@gmail.com', 'قلب و عروق', 0, '29000', '015', '123', 'doctor11.jpg'),
(36, '', 'دکتر یاشار عباسی', 'بیمارستان امام', '03256589', 'Dr.yashar-abbasi@gmail.com', 'مغز و اعصاب', 0, '38000', '016', '123', 'doctor23.jpg'),
(37, '', 'دکتر افسانه شیخی', 'بیمارستان ارتش', '0325442654', 'Dr.Afsaneh-sh@gmail.com', 'قرینه و چشم', 0, '45000', '017', '123', 'doctor15.jpg'),
(38, '', 'دکتر سعید اصلانی', 'بیمارستان ارتش', '02156235', 'Dr.Saeed-aslani@yahoo.com', 'قلب و عروق', 0, '36000', '018', '123', 'doctor11.jpg'),
(39, '', 'رامین محمدی', 'بیمارستان باهنر', '09901234567', 'dr.r-mohammadi@yahoo.com', 'داخلی و اطفال', 0, '50000', '019', '1234', 'doctor24.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `email` varchar(22) NOT NULL,
  `feedback` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `email`, `feedback`) VALUES
(1, 'yasymasoomi@gmail.com', 'سلام');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `age` varchar(22) NOT NULL,
  `contact` varchar(22) NOT NULL,
  `address` varchar(50) NOT NULL,
  `rdoctor` varchar(22) NOT NULL,
  `email` varchar(111) NOT NULL,
  `password` varchar(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`id`, `name`, `age`, `contact`, `address`, `rdoctor`, `email`, `password`) VALUES
(1, 'یاسمن', '19', '09136651344', 'کرمان', '4', 'yasymasoomi@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `type`) VALUES
('admin', '1234', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Representative doctor`
--
ALTER TABLE `Representative doctor`
  ADD PRIMARY KEY (`bg_id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`doc_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Representative doctor`
--
ALTER TABLE `Representative doctor`
  MODIFY `bg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `doc_id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
