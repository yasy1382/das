<?php include('header.php'); ?>


	<!-- mc info -->
	<div class="doctors">
        
		                    <h3 class="text-center" style="background-color:#272327;color: #fff;height: 30px">لیست پزشکان</h3>
                            <div class="col-md-12" style="">
                                  


                                  <div class="col-md-3">
                                      <img src="img/doctor5.jpg" alt="" class="img-responsive" style="width: 220px;height: 220px">
                                  </div> <br>

                                  <div class="col-md-3" > 

                                     
                                     <h3 style="color:#0616BC;">دکتر معصومه فرج پور</h3>


                                        <!-- Accordian Starts -->
                                            <div  dir="rtl" class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title" >
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                      تخصص
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                                  <div class="panel-body">
                                                      MBBS ، BCS (بهداشت) ، MS (متخصص زنان و زایمان) متخصص زنان و زایمان
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingTwo">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                      مطب
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                  <div class="panel-body">
                                                        مطب : تهران میدان 15 خیابان 29 پلاک1
                                                       
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                      شماره تماس هماهنگی
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                  <div class="panel-body">
تلفن : 02185856598                                                  </div>
                                                </div>
                                              </div>

                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a href="patient_login.php">
                                                      نوبت گیری
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>

                                            </div>


                                            <!-- Accordian End -->
                                        


                                  </div>

                                 <div class="col-md-3">
                                      <img src="img/doctor3.jpg" alt="" class="img-responsive" style="width: 220px;height: 220px"> <br>
                                  </div>

                                  <div class="col-md-3">
                                       
                                       <h3 style="color:#0616BC;">دکتر سعید نیک نام</h3>

                                             <!-- Accordian Start -->

                                            <div dir="rtl" class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne1">
                                                  <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne1" aria-expanded="true" aria-controls="collapseOne1">
                                                      تخصص
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne1">
                                                  <div class="panel-body">
                                                      MBBS ، MCPS مشاور ارشد متخصص قلب و ریه، آنژیو گرافی، آندوسکوپی
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingTwo2">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo2" aria-expanded="false" aria-controls="collapseTwo2">
                                                      مطب
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo2">
                                                  <div class="panel-body">
دانشکده پزشکی تهران بلوار 4 طبقه 6 واحد 2
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree3">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree3" aria-expanded="false" aria-controls="collapseThree3">
                                                      شماره تماس هماهنگی
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree3">
                                                  <div class="panel-body">
                                                     تلفن : 021569842356
                                                  </div>
                                                </div>
                                              </div>

                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a href="patient_login.php">
                                                      نوبت گیری
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>

                                            </div>
                                        
                                          <!-- Accordian End -->  
                                            
                                   </div> 
                             </div> <!-- col-md-12 End-->

                            <br><br>


                             <div class="col-md-12" style="">
                                  


                                  <div class="col-md-3">
                                      <img src="img/doctor4.jpg" alt="" class="img-responsive" style="width: 220px;height: 220px">
                                  </div>

                                  <div class="col-md-3" > 

                                     
                                     <h3 style="color:#0616BC;">دکتر شیرین بهرامی</h3>


                                        <!-- Accordian Starts -->
                                            <div dir="rtl" class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne11" aria-expanded="true" aria-controls="collapseOne11">
                                                      تخصص
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne11" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                                  <div class="panel-body">
                                                      MBBS ، MS (جراحی مغز و اعصاب) تخصص: مغز ، عصب و ستون فقرات ، جراح مغز و اعصاب
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingTwo">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo22" aria-expanded="false" aria-controls="collapseTwo22">
                                                      مطب
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo22" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                  <div class="panel-body">
بیمارستان 14 بلوار 13 پلاک 14 طبقه 2 اتاق 21
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree33" aria-expanded="false" aria-controls="collapseThree33">
                                                     شماره تماس هماهنگی
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree33" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                  <div class="panel-body">
تلفن : 02156894152                                                  </div>
                                                </div>
                                              </div>

                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a href="patient_login.php">
                                                      نوبت گیری
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>


                                            </div>


                                            <!-- Accordian End -->
                                        


                                  </div>

                                 <div class="col-md-3">
                                      <img src="img/doctor1.jpg" alt="" class="img-responsive" style="width: 220px;height: 220px">
                                  </div>

                                  <div class="col-md-3">
                                       
                                       <h3 style="color:#0616BC;">دکتر حسن آریا</h3>

                                             <!-- Accordian Start -->

                                            <div dir="rtl" class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne111" aria-expanded="true" aria-controls="collapseOne111">
                                                      تخصص
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne111" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                                  <div class="panel-body">
                                                        داخلی اطفال دارای برد تخصصی MMA در زمینه سیستم گوارش اطفال
Medicine Specialist
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingTwo">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo222" aria-expanded="false" aria-controls="collapseTwo222">
                                                      مطب
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo222" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                  <div class="panel-body">
خیابان 14 برج آزادی طبقه 18 واحد6 پلاک 2
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree333" aria-expanded="false" aria-controls="collapseThree333">
                                                      شماره تماس هماهنگی
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree333" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                  <div class="panel-body">
                                                     تلفن : 02156893254
                                                  </div>
                                                </div>
                                              </div>

                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a href="patient_login.php">
                                                      نوبت گیری
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>
                                              
                                            </div>
                                        
                                          <!-- Accordian End -->  
                                            
                                   </div> 
                             </div> <!-- col-md-12 End-->



                              

                            <br><br>


                             




	</div> <!-- Doctors End -->

    <!-- footer section --> 
			 <?php include('footer.php'); ?>
    <!-- footer section Ends--> 
	



		
	</div><!--  containerFluid Ends -->


               <script src="js/jquery-1.11.3.min.js"></script> <!-- this works for collapse -->
                <script src="js/bootstrap.min.js"></script>
	
</body>
</html>






