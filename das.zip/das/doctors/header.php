<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>سیستم نوبت دهی پزشک</title>
	<link rel="stylesheet" href="../patient/css/bootstrap.min.css">
	<link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="../RtlStyle.css">

    <style>
		.error {color: #FF0000;}
	</style>
</head>
<body>


<?php
		if($_SESSION['adminstatus'] == ""){
			header("location:doctorlogin.php");
		}
		
		   

	 ?>


<div class="container-fluid">
    <div class="header_top" style="text-align: right;padding-right: 20px;padding-top: 20px;">

            <span style="font-family:IRANSans;text-align:right;font-size:40px;color:#2c2f84;font-weight:bolder;">سیستم نوبت دهی پزشک</span>
		</div>

	<!-- 	this is for menu -->
	<div class="navbar navbar-default nav" style="height: 42px;">
		<nav class="menu">
			<ul>
                <li><a href="../patient/logout.php">خروج</a></li>

                <li><a href="myAppoinment.php">وقت ملاقات</a></li>
				<li><a href="myCustomer.php">اطلاعات بیماران</a></li>
				<li><a href="myDetails2.php">ویرایش اطلاعات</a></li>
				<li><a href="myDetails.php">اطلاعات من</a></li>
			</ul>
		</nav>
	</div>
	
