   <!-- footer section --> 
			<footer>
				<div class="col-md-12 fsection">
                    <div class="col-md-4 share_img">
                        <p>شبکه های اجتماعی</p> <hr>
                        <a href="" ><img src="img/fb-free.png" alt="facebok"></a>
                        <a href=""><img src="img/gogle-plud-free.png" alt="google-plus"></a>
                        <a href=""><img src="img/twitter.png" alt="twitter"></a>

                    </div>
					<div class="col-md-4">
						<p>تماس با ما</p> <hr>
						<p>نام پشتیبانی <br>
							ایمیل :tarmim.sinamail@gmail.com <br>
							تلفن : 03432521818</p>
							<span style="color: red;font-size: 15px">&copy;<?php echo date('Y'); ?>-All Rights Reserved</span>
					</div>


                    <div class="col-md-4" id="contact">
                        <p>دسته بندی</p> <hr>
                        <ul>
                            <li><a href="signin.php">جستجو</a></li>
                            <li><a href="signin.php">تماس با ما</a></li>

                        </ul>
                    </div>
				</div>
				

			</footer>

		<!-- footer section Ends--> 
