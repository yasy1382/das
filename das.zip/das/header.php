<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>سیستم نوبت دهی آنلاین شرکت ترمیم بافت سینا</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="RtlStyle.css">

</head>
<body>
	<div class="container-fluid">
		<div class="header_top" style="text-align: right;padding-right: 20px;padding-top: 20px;">
			<span style="font-family:IRANSans;text-align:right;font-size:40px;color:#2c2f84;font-weight:bolder;">سیستم نوبت دهی شرکت ترمیم بافت سینا</span>
		</div>

	<!-- 	this is for menu -->
	<div class="navbar navbar-default nav" style="height: 42px;" >
		<nav class="menu">
			<ul >
                <li><a href="about.php">درباره ما</a></li>
				<li><a href="contactus.php">تماس با ما</a></li>
                <li><a href="doctorinfo.php">پزشکان</a></li>
				<li><a href="signin.php">ورود بیمار/ پزشک</a></li>
				<li><a href="admin/adminlogin.php">بخش مدیریت</a></li>
                <li><a href="index.php">صفحه اصلی</a></li>


            </ul>
		</nav>
	</div>
	
