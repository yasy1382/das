<?php include('header.php'); ?>
<link rel="stylesheet" href="RtlStyle.css">

	<!-- this is for welcome -->
	<div class="content">
		<article>
<!--			<img src="img/welcome1.png" alt="welcome msg">-->
            <h3> سیستم نوبت دهی بیماران بصورت آنلاین
            </h3>
			<p class="text-justify">
			در این سیستم شما می توانید با ثبت اطلاعات نوبت خود را بدون نیاز به مراجعه ی حضوری رزرو کنید. این سیستم بصورت آزمایشی با زبان php نوشته شده است. در این سیستم شما می توانید بدون فوت وقت پرونده بسازید و همچنین از تاریخ مراجعات بعدی خود اطلاع کسب کنید. برای نوبت گیری از شرکت ابتدا باید در سیستم عضو شوید. عضو گیری از طریق لیست بالا و در قسمت ورود بیمار/ پزشک امکان پذیر است. 
			</p>

1            <ul class="tik">
                <li>                در عملیات رزرو و اخذ نوبت در انتخاب روز و تاریخ نوبت درخواستی دقت نمایید.
                </li>
                <li>                در روز و ساعت تعیین شده در محل حضور داشته باشید.
                </li>
                <li>                از کدملی بیمار برای رزرو نوبت استفاده نمایید در غیر اینصورت شرکت ترمیم بافت سینا مسئولیتی در قبال پذیرش شما نخواهد داشت.
                </li>
                <li>                ثبت نوبت درخواستی شما در سیستم منوط به دریافت کدپیگیری می باشد.
                </li>
                <li>                با آی پی های خارج از کشور امکان رزرو نوبت وجود ندارد
                </li>
            </ul>



		</article>



	</div><br>

	<!-- nivo slider starts -->
	<div class="col-md-12 sliderImg">
		<img src="img/doctor1.jpg" alt="">
		<img src="img/doctor2.jpg" alt="">
		<img src="img/doctor3.jpg" alt="">
		<img src="img/doctor4.jpg" alt="">
		<img src="img/doctor5.jpg" alt="">
		<img src="img/doctor6.jpg" alt="">
	</div>
	<!-- nivo slider ends -->

	<!-- main Content -->
	<div class="main_content">
		<div class="col-md-8">
			<article>
			<h3 style="font-weight: bold;font-family:inherit;">در هر مکان و زمانی به آسانی نوبت رزرو کنید!</h3><hr>
				<p class="text-justify">
                    شرکت ترمیم بافت سینا اولین شرکت تولید محصولات بازساختی با بهترین و مجرب ترین کادر در خدمت شماست! سلامت خود را به ما بسپارید

				</p>
			</article>
		</div>
		<div class="col-md-4">
			<h3 class="text-center" style="font-weight:bold;font-family:inherit;">نوبت دهی پزشک </h3><hr>
			<ul class="text-justify">
            ترمیم بافت سینا. 🔹️مرکز تخصصی تهیه پی آر پی و انواع ژل های پلاسمایی 🔹️بانک سلولهای بنیادی دندان های شیری کرمان نبش جهاد ۱ برج پزشکان پاستور طبقه ۶
            </ul>
		</div>

          
    </div>

 	<?php include('footer.php'); ?>


	
</div>	<!--  containerFluid Ends -->



	<script src="js/jquery-1.9.0.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

	 
	
</body>
</html>