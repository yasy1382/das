<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<?php include('header.php'); ?>
<?php include('uptomenu.php'); ?>

	
<!-- result -->
<?php 
	$doc_id = isset($_GET['doc_id'])?$_GET['doc_id']:"";
	
 ?>
				<!-- fetching doctor info -->
					<?php 
					include('../config.php');
					

							$sql="SELECT * FROM doctor WHERE doc_id = $doc_id ";

							$result = $conn->query($sql);
							if ($result->num_rows > 0) {
							    // output data of each row
							    while($row  = $result->fetch_assoc()) {
							        $doc_id   = $row["doc_id"];
							        $name 	= $row["name"];
							        $expertise 	= $row["expertise"];
							        $contact 	= $row["contact"];
							        $fee = $row["fee"];
									 $userid = $row["userid"];
							    }
							}
							
							$conn->close();

					?>
					<!-- fetching doctor info -->

	<!-- 	booking info-->
		<div dir="rtl" class="login" style="background-color:#fff;">
		<h3 class="text-center" style="background-color:#272327;color: #fff;">رزرو نوبت</h3>
			<div class="formstyle" style="font-family:IRANSans;float: right;padding:20px;border: 1px solid lightgrey;margin-right:415px; margin-bottom:30px;background-color:#f3f3f8;color:#141313;">
				<form action="" method="post" class="text-center form-group" enctype="multipath/form-data">
					

					<label style="float: left;">
						نام پزشک: <input style="float: left;" type="text" name="dname" value="<?php echo $name; ?>" >
					</label><br><br>

 					<label style="float: left;">
						شماره تماس: <input style="float: left;" type="text" name="dcontact" value="<?php echo $contact; ?>" />
					</label><br><br>
 					
					<label style="float: left;">
						تخصص: <input style="float: left;" type="text" name="expertise" value="<?php echo $expertise; ?>" >
					</label><br><br>

					<label style="float: left;">
						هزینه: <input style="float: left;" type="text" name="fee" value="<?php echo $fee; ?>" >
					</label><br><br>
					<label style="float: left;">
						نام بیمار: <input style="float: left;" type="text" name="pname" value="">
					</label><br><br>

 					<label style="float: left;">
						 شماره بیمار: <input style="float: left;"type="text" name="pcontact" value=""/>
					</label><br><br>
					<label style="float: left;">
						 ایمیل: <input style="float: left;" type="email" name="email" value=""/>
					</label><br><br>
 					
					<label style="float: left;">
						 آدرس: <input style="float: left;" type="text" name="address" value="">
					</label><br><br>
					<label style="float: left;">
						 تاریخ: <input style="float: left;" type="date" name="dates" value="">
					</label><br><br>
					<label style="float: left;">
						 ساعت: <select style="float: left;" name="tyme" required>
										<option value="">-انتخاب-</option>
										<option value="11.00am">11.00 قبل از ظهر</option>
										<option value="03.00pm">03.00 بعد از ظهر</option>
									</select>
					</label><br><br>
					<label style="float: left;">
						 نوع پرداخت <select style="float: left;" name="payment" required>
										<option value="">-انتخاب-</option>
										<option value="Rocket">کارت عضو شتاب</option>
										<option value="bKask">نقدی</option>
									</select>
					</label><br><br>
					<label style="float: left;">
						  <input style="float: left;" type="hidden" name="userid" value="<?php echo $userid; ?>">
					</label><br><br>

					<button name="submit" type="submit" style="padding-right:5px;border-radius:3px;margin-right:;">تایید</button>
					<a href="search_doctor.php"><button name="" type="" style="padding-right:5px;border-radius:3px;margin-right:-150px;">انصراف</button></a> <br>


				</form> <br><br>

			</div>
	
	
		</div>
				<!-- 	booking info-->
				
			<!-- confirming booking -->
					<?php

						include('../config.php');
						if(isset($_POST['submit'])){
							

						$sql = " INSERT INTO booking (dname,userid,dcontact,expertise,fee, pname,pcontact,email,address,dates,tyme,payment)
							VALUES ('" . $_POST["dname"] . "','" . $_POST["userid"] . "','" . $_POST["dcontact"] . "','" . $_POST["expertise"] . "', '" . $_POST["fee"] . "','" . $_POST["pname"] . "','". $_POST["pcontact"] . "','". $_POST["email"] . "','". $_POST["address"] . "','". $_POST["dates"] . "','". $_POST["tyme"] . "','". $_POST["payment"] . "' )";

							if ($conn->query($sql) === TRUE) {
							    echo "<script>alert('نوبت شما با موفقیت رزرو شد');</script>";
							} else {
							    echo "<script>alert('خطا در سیستم !!!')<script>";
							}

							$conn->close();
						}
					?> 

				<!-- confirming booking -->

	
	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>


 


	
</body>
</html>
