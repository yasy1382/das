<?php if(!isset($_SESSION)){
    session_start();
}

include('../config.php');
$id=$_GET["booking_id"];
$sql = " DELETE FROM booking WHERE booking_id= '".$id."'";
if ($conn->query($sql) === TRUE) {
    echo "<script>alert('نوبت شما با موفقیت حذف شد');</script>";
} else {
    echo "<script>alert('خطا در سیستم !!!') <script>";
}

$conn->close();
header("Location: view_booking.php");

