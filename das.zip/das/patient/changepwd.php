<?php if(!isset($_SESSION)){
	session_start();
	}  
?>

<?php include('header.php'); ?>
<?php include('uptomenu.php'); ?>



	<!-- this is for donor registraton -->
	<div dir="rtl" class="dashboard" style="font-family: IRANSans; background-color:#fff;">
		<h3 class="text-center" style="background-color:#272327;;color: #fff;padding: 5px;">تغییر کلمه عبور</h3>
		<div class="formstyle" style="float: right;padding:20px;border: 1px solid lightgrey;margin-right:415px; margin-bottom:30px;background-color:#f3f3f8;color:#141313;">
				<form action="" method="post" class="text-center">
					<label style="float: left;">
						<span style=" color: #000">کلمه عبور قبلی : </span><input style="float: left;" type="password" name="password"  placeholder="کلمه عبور قبلی" required>
					</label><br><br>
					<label style="float: left;">
						<span style="color: #000">کلمه عبور جدید : </span><input style="float: left;" type="password" name="newpassword"  placeholder="کلمه عبور جدید" required>
					</label><br><br>
					<label style="float: left;">
						<span style="color: #000">تکرار کلمه عبور جدید : </span><input style="float: left;" type="password" name="confpassword"  placeholder=" تکرار کلمه عبور جدید" required>
					</label>
                    <br>
                    <br>
                    <br>
                    <br>
					<button name="submit" type="submit" style="border-radius: 3px;color:#000;margin-right: -51px;">تغییر کلمه عبور</button> <br>

					


					<!-- login validation -->
			<?php 
					
							
							include('../config.php');
							if(isset($_POST["submit"])){
							

							$sql= "SELECT * FROM patient WHERE email= '" . $_SESSION["email"]."' AND password= '" . $_POST["password"]."'";

							$query=mysqli_query($conn,$sql);
							$row=mysqli_num_rows($query);
							$newpassword=$_POST[newpassword];
                            $confpassword= $_POST[confpassword];

							if($row>0){
								//check the new password
								if($newpassword==$confpassword){
								
								$sql1="UPDATE patient SET password='" . $_POST["newpassword"]  ."' WHERE email='" .$_SESSION["email"] ."'";
								mysqli_query($conn,$sql1);
								mysqli_close($conn);
								echo "<script>alert('کلمه عبور شما با موفقیت تغییر یافت');</script>";
								
								}else{
									echo "<script>alert('کلمه عبور جدید و تکرار آن برابر نیست');</script>";

								}


							}else{
								echo "<script>alert('کلمه عبور فعلی شما نادرست وارد شده است');</script>";
							}
									
										
								
					}
					
 			?>
		<!-- login validation End-->


				</form> <br>&nbsp;&nbsp;&nbsp;
				
				<br>

				
		
				
			
		
	</div>
		
		
			
		
	</div>
	
	

	
 <?php include('../footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>


 
			



	
</body>
</html>
