   <!-- footer section -->

   <footer>
				<div class="col-md-12 fsection">
                    <div class="col-md-4 share_img">
                        <p>شبکه های اجتماعی</p>
                        <a href=""><img src="img/fb.png" alt=""></a>
                        <a href=""><img src="img/feed.png" alt=""></a>
                        <a href=""><img src="img/twiter.png" alt=""></a>
                    </div>
					<div class="col-md-4">
						<p>تماس با ما</p>
						<p>سیستم نوبت دهی <br>
							جزئیات</p>
						
					</div>

                    <div class="col-md-4" id="contact">
                        <p>دسته بندی</p>
                        <ul>
                            <li><a href="#">ثبت نام</a></li>
                            <li><a href="#">تماس با پزشک</a></li>

                        </ul>
                    </div>
				</div>
				

			</footer>

		<!-- footer section Ends--> 
