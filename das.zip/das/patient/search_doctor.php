<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<?php include('header.php'); ?>
<?php include('uptomenu.php'); ?>

<!-- <?php include('function.php'); ?> -->



	<!-- this is for donor registraton -->
	<div dir="rtl" class="search" style="background-color:;">
		<h3 class="text-center" style="background-color:#272327;color: #fff;padding: 5px;">جستجوی پزشک</h3>

		 <div  class="formstyle" style="font-family:IRANSans;padding:70px;border: 1px solid lightgrey;margin-right: 293px;margin-bottom: 30px;background-color:#f3f3f8;color:#141313;width: 530px;margin-left: 400px;">
					<form action="search_result.php" method="post" class="form-group">

					<!-- testing -->
					<label style="float:left;">
						بیمارستان:<select id="options" style="float:left;" name="address" type="text" style="width: 110px;margin-right: 175px;" />
												<option>-انتخاب بیمارستان-</option>
                        <?php
                        include('../config.php');


                        $sql = " SELECT DISTINCT address FROM category";
                        $result = mysqli_query($conn,$sql);
                        $count = mysqli_num_rows($result);
                        $hos=array();
                        $i=0;
                        if($count>=1) {
                            while ($row = mysqli_fetch_array($result)) {
                                echo "<option>" . $row['address'] . "</option>";
                                $hos[$i++]=$row['address'];


                            }
                        }


                        ?>
                        </select>

					</label><br><br>
					<!-- testing end-->

					<label style="float:left;">
						 تخصص:<select id="choices" style="float:left;" name="expertise"  type="text" style="width: 110px;margin-right: 175px;" />
                        <option value="" disabled selected>-انتخاب تخصص-</option>

                        </select>


                    </label>
					<button name="submit" type="submit" style="font-family:IRANSans;border-radius: 3px;color:#000;float:left;margin-top: 8px;">جستجو</button>
					<br>
					
					</form>



					
		 	</div>
	</div>
	
	

	
 <?php include('../footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

<script>
    var lookup = {
        <?php
        $i=0;
        for($i=0;$i<count($hos);$i++)
        {
            echo '\'';
            echo $hos[$i];
            echo '\'';
            $sql = " SELECT DISTINCT cat FROM category WHERE address='".$hos[$i]."'";
            $result = mysqli_query($conn,$sql);
            $count = mysqli_num_rows($result);
            if($count>=1){
                echo ": [";
                while($row=mysqli_fetch_array($result)){
//                    echo ": ['1', '2', '3'],";
                    echo '\'';
                    echo $row['cat'];
                    echo '\'';
                    echo ',';

                }
                echo '],';
            }

        }


        ?>

    };

    // When an option is changed, search the above for matching choices
    $('#options').on('change', function() {
        // Set selected option as variable
        var selectValue = $(this).val();

        // Empty the target field
        $('#choices').empty();

        // For each chocie in the selected option
        for (i = 0; i < lookup[selectValue].length; i++) {
            // Output choice in the target field
            $('#choices').append("<option value='" + lookup[selectValue][i] + "'>" + lookup[selectValue][i] + "</option>");
        }
    });

</script>




</body>
</html>