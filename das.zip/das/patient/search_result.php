<?php if(!isset($_SESSION)){
	session_start();
	}  
?>
<?php include('header.php'); ?>
<?php include('uptomenu.php'); ?>

	<div class="search form-group"  style="background-color: #7faf81;">
		<h3 class="text-center" style="background-color:#272327;color: #fff;padding: 5px;">نتیجه جستجو</h3>
		
	</div>
<!-- result -->

					<?php 
					include('../config.php');
					

					$sql = " SELECT * FROM doctor WHERE address = '" . $_POST["address"]."' AND expertise = '" . $_POST["expertise"]."' ";
					$result = mysqli_query($conn,$sql);
					$count = mysqli_num_rows($result);

					if($count>=1){
						echo "<table dir='rtl' style='font-family: IRANSans' border='1' align='center' cellpadding='32'>
							<tr>
								<th style='text-align: center;'>شماره</th>
								<th style='text-align: center;'>نام پزشک</th>
								<th style='text-align: center;'>آدرس</th>
								
								<th style='text-align: center;'>شماره تماس</th>
								
								<th style='text-align: center;'>ایمیل</th>
								<th style='text-align: center;'>تخصص در</th>
								<th style='text-align: center;'>هزینه</th>
								<th style='text-align: center;'>نوبت دهی</th>
								
							</tr>";
						while($row=mysqli_fetch_array($result)){
								echo "<tr>";
								echo "<td>".$row['doc_id']."</td>";
								echo "<td>".$row['name']."</td>";
								echo "<td>".$row['address']."</td>";
								
								echo "<td>".$row['contact']."</td>";
								echo "<td>".$row['email']."</td>";

								echo "<td>".$row['expertise']."</td>";
								echo "<td>".$row['fee']."</td>";
						?>
							<td><a href="booking.php?doc_id=<?php echo $row['doc_id'] ?>">رزرو کردن</a></td>;
						<?php 		
								
								echo "</tr>";
						}
						echo "</table>";
					} 
					else{
						print "<p align='center'>متاسفانه هیچ موردی یافت نشد !!!</p>";
					}

					?>
					<!-- result -->


	<button style="margin-left: 605px;background-color:#332f30;color: antiquewhite;width: 115px;height: 30px;margin-bottom: 5px;">
	<a style="font-family: IRANSans;" href="search_doctor.php">جستجوی دوباره</a></button>
	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>


 


	
</body>
</html>
