<div class="container-fluid">
		<div dir="rtl" class="header_top">

            <span style="font-family:IRANSans;text-align:right;font-size:40px;color:#2c2f84;font-weight:bolder;">سیستم نوبت دهی پزشک</span>
		</div>

	<!-- 	this is for menu -->
	<div class="navbar navbar-default nav" style="height: 42px;">
		<nav class="menu">
			<ul>
                <li><a href="logout.php">خروج</a></li>
                <li><a href="feedback.php">پیام های شما</a></li>
				<li><a href="changepwd.php">تغییر رمز عبور</a></li>
                <li><a href="view_booking.php">مشاهده نوبت</a></li>
                <li><a href="search_doctor.php">جستجوی پزشک </a></li>
                <li><a href="myDetails.php">اطلاعات من</a></li>

            </ul>
		</nav>
	</div>