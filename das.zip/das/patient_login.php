<?php session_start();  ?>
<?php include('header.php'); ?>





	<!-- this is for donor registraton -->
	<div dir="rtl" class="login" style="background-color:#fff;">
		<h3 class="text-center" style="height:30px;background-color:#272327;color: #fff;">ورود بیمار (نوبت دهی)</h3>
			<div class="formstyle" style="float: right;padding:20px;border: 1px solid lightgrey;margin-right:550px; margin-bottom:30px;background-color:#f3f3f8;color:#141313;">
				<form action="" method="post" class="text-center form-group">
					<label>
						 <input type="email" name="email"  placeholder="ایمیل" required style="margin-right: 20px">
                    </label><br><br>
					<label>
						 <input type="password" name="password"  placeholder="کلمه عبور" required style="margin-right: 20px" >
					</label><br><br>
					<button name="submit" type="submit" style="margin-left: -26px;width: 85px;border-radius: 3px; margin-top: 15px;">ورود</button> <br>

                    <br>
					<span style="color:#000; margin-top: 25px;">هنوز ثبت نام نکرده اید؟</span> <a href="patient_regi.php" title="create a account" target="" style="color:rgba(۱۳۷,۰,۱,0.92);">&nbsp;ثبت نام</a> <br>


					<!-- login validation -->
                    <?php
                    $_SESSION['patient']="";

                    include('config.php');
                    if(isset($_POST["submit"])){


                        $sql= "SELECT * FROM patient WHERE email= '" . $_POST["email"]."' AND password= '" . $_POST["password"]."'";

                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            $_SESSION["email"]= $_POST["email"];

                            $_SESSION['patient']= "yes";
                            echo "<script>location.replace('patient/dashboard.php');</script>";
                            // echo "u are supposed to redirect to ur profile";
                        } else {
                            echo "<span style='color:red;'>نام کاربری یا کلمه عبور اشتباه است</span>";
                        }
                        $conn->close();
                    }

                    ?>
                    <!-- login validation End-->


				</form> <br>&nbsp;&nbsp;&nbsp;
				
				<br>

				
		
				
			
		
	</div>
	
	
</div>
	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>


 
			



	
</body>
</html>

