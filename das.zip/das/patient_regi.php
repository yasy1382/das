<?php include('header.php'); ?>





	<!-- this is for donor registraton -->
	<div class="recipient_reg" style="background-color:#272327;">
		<h3 class="text-center" style="height:30px;background-color:#272327;color: #fff;">ثبت نام بیمار (نوبت دهی)</h3>

		<div class="formstyle" style="float: right;padding:25px;border: 1px solid lightgrey;margin-right:500px; margin-bottom:30px;background-color:#f3f3f8;color:#141313;">
		<form enctype="multipart/form-data" method="post" class="text-center">
			 <div class="col-md-12" dir="rtl">
				  
			 		<label>
                        <input type="text" name="name" value="" placeholder="نام و نام خانوادگی" required style="margin-right: 20px"/>
					</label><br><br>

					<label>
						 <input type="number" name="age"  placeholder="سن" pattern="[0-9]{2,2}" title="please enter only  numbers between 2 to 2 for age" style="margin-right: 20px"/>
					</label><br><br>
					<label>
					  <input type="number" name="contact"  placeholder="شماره تماس" required="required" pattern="[0-9]{10,11}" title="please enter only numbers between 10 to 11 for mobile no." style="margin-right: 20px"/>
					</label><br><br>
 					
 					<label>
						<input type="text" name="address" value="" placeholder="آدرس" style="margin-right: 20px">
					</label><br><br>
					<label>
						<select name="bgroup" required style="margin-right: 20px">
										<option value="">پزشک معرف</option>
										<option value="1">doctor1</option>
										<option value="2">doctor2</option>
										<option value="3">doctor3</option>
										<option value="4">doctor4</option>
										<option value="5">doctor5</option>
										<option value="6">doctor6</option>
									</select>
					</label><br><br>
					<label>
						 <input type="email" name="email"  value="" placeholder="ایمیل" required style="margin-right: 20px">
					</label><br><br>
					<label>
						<input type="password" name="password"  value="" placeholder="کلمه عبور" required style="margin-right: 20px">
					</label><br><br>
					
					
					<button name="submit" type="submit" style="margin-right:20px; margin-top:20px;width: 85px;border-radius: 3px;">ثبت نام</button> <br>
				
			</div>	<!-- col-md-12 -->


				</form>
			</div>




	</div>
	
	



	
	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>


	 <!-- validation and insertion -->


				<?php
						include('config.php');
						if(isset($_POST['submit'])){

						$sql1 = "SELECT * FROM patient WHERE email='".$_POST["email"]."' ";
             		    $result = $conn->query($sql1);	
             		    if ($result->num_rows > 0) {
			                  echo "<script>alert('قبلاً با این ایمیل ثبت نام شده است');</script>";
			             }
						else{
							$sql = "INSERT INTO patient (name,age,contact,address,bgroup,email, password)
							VALUES ('" . $_POST["name"] ."','" . $_POST["age"] . "','" . $_POST["contact"] . "','" . $_POST["address"] . "','" . $_POST["bgroup"] . "', '" . $_POST["email"] . "','" . $_POST["password"] . "' )";

							if ($conn->query($sql) === TRUE) {
							    echo "<script>location.replace('patient_success_msg.php');</script>";
							} else {
							    echo "<script>alert('خطا در سیستم')<script>" . $sql . "<br>" . $conn->error;
							}

							$conn->close();
						}
					}
				?> 



	<!-- validation and insertion End-->



</body>
</html>