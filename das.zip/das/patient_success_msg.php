<?php include('header.php'); ?>

	<!-- this is for donor registraton -->
	<div dir="rtl" class="login" style="background-color:#fff;">
		<h1 class="text-center" style="background-color:#272327;color: #fff;">تبریک</h1>
		 		<p class="text-center">شما در سیستم با موفقیت ثبت نام کردید</p>
        <br>
        <br>
        <p style="text-align: center">برای ورود به پنل کاربری خود روی لینک زیر کلیک کرده و ایمیل و کلمه عبور خود را وارد کنید </p>
        <div style="text-align: center">
        <a href="patient_login.php" style="text-align: center;color: #D50000;font-size: 20px;"> ورود به حساب کاربری</a>
        </div>

       <br>
        <br>



    </div>
	
	
</div>
	
	

	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>


	
</body>
</html>
